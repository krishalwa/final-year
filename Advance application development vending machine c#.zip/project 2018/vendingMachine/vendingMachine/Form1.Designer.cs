﻿namespace vendingMachine
{
    partial class Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form));
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.txtproductname = new System.Windows.Forms.TextBox();
            this.txtProductprice = new System.Windows.Forms.TextBox();
            this.txtProductqty = new System.Windows.Forms.TextBox();
            this.btnADDproduct = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.btnDataentryClose = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btnCoke = new System.Windows.Forms.Button();
            this.btnTea = new System.Windows.Forms.Button();
            this.btnMilk = new System.Windows.Forms.Button();
            this.btnPepsi = new System.Windows.Forms.Button();
            this.btnFanta = new System.Windows.Forms.Button();
            this.btnSprite = new System.Windows.Forms.Button();
            this.btnDrpeper = new System.Windows.Forms.Button();
            this.btn7up = new System.Windows.Forms.Button();
            this.txtPassword = new System.Windows.Forms.TextBox();
            this.button10 = new System.Windows.Forms.Button();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.btnPrdcancel = new System.Windows.Forms.Button();
            this.btnBuyprd = new System.Windows.Forms.Button();
            this.lblProdQty = new System.Windows.Forms.Label();
            this.lblProdPrice = new System.Windows.Forms.Label();
            this.lblProdName = new System.Windows.Forms.Label();
            this.groupBoxSerializaiton = new System.Windows.Forms.GroupBox();
            this.btn_BINARY_DESERILZ = new System.Windows.Forms.Button();
            this.btnBINARY_serialization = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.btnBinaryDeserialization = new System.Windows.Forms.Button();
            this.btnBInarySerialization = new System.Windows.Forms.Button();
            this.btnSortbyproduct = new System.Windows.Forms.Button();
            this.grpboxCoins = new System.Windows.Forms.GroupBox();
            this.label6 = new System.Windows.Forms.Label();
            this.button4 = new System.Windows.Forms.Button();
            this.btnconfirmbuy = new System.Windows.Forms.Button();
            this.coins = new System.Windows.Forms.ListBox();
            this.lblCoinsTotal = new System.Windows.Forms.Label();
            this.button9 = new System.Windows.Forms.Button();
            this.btnTotal = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.btnOnepound = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.btnFivepence = new System.Windows.Forms.Button();
            this.btnReset = new System.Windows.Forms.Button();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.grpsorting = new System.Windows.Forms.GroupBox();
            this.btnSortbyqty = new System.Windows.Forms.Button();
            this.lblTotalQnty = new System.Windows.Forms.Label();
            this.btnTotalQnty = new System.Windows.Forms.Button();
            this.btnnewtotal = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.button7 = new System.Windows.Forms.Button();
            this.printPreviewDialog1 = new System.Windows.Forms.PrintPreviewDialog();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBoxSerializaiton.SuspendLayout();
            this.grpboxCoins.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.grpsorting.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(32, 32);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(4);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(601, 308);
            this.dataGridView1.TabIndex = 1;
            // 
            // txtproductname
            // 
            this.txtproductname.Font = new System.Drawing.Font("Modern No. 20", 9.857142F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtproductname.Location = new System.Drawing.Point(32, 415);
            this.txtproductname.Margin = new System.Windows.Forms.Padding(4);
            this.txtproductname.Name = "txtproductname";
            this.txtproductname.Size = new System.Drawing.Size(139, 32);
            this.txtproductname.TabIndex = 2;
            this.txtproductname.Validating += new System.ComponentModel.CancelEventHandler(this.txtproductname_Validating);
            // 
            // txtProductprice
            // 
            this.txtProductprice.Font = new System.Drawing.Font("Modern No. 20", 9.857142F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtProductprice.Location = new System.Drawing.Point(187, 415);
            this.txtProductprice.Margin = new System.Windows.Forms.Padding(4);
            this.txtProductprice.Name = "txtProductprice";
            this.txtProductprice.Size = new System.Drawing.Size(136, 32);
            this.txtProductprice.TabIndex = 3;
            // 
            // txtProductqty
            // 
            this.txtProductqty.Font = new System.Drawing.Font("Modern No. 20", 9.857142F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtProductqty.Location = new System.Drawing.Point(329, 415);
            this.txtProductqty.Margin = new System.Windows.Forms.Padding(4);
            this.txtProductqty.Name = "txtProductqty";
            this.txtProductqty.Size = new System.Drawing.Size(136, 32);
            this.txtProductqty.TabIndex = 4;
            // 
            // btnADDproduct
            // 
            this.btnADDproduct.Location = new System.Drawing.Point(499, 395);
            this.btnADDproduct.Margin = new System.Windows.Forms.Padding(4);
            this.btnADDproduct.Name = "btnADDproduct";
            this.btnADDproduct.Size = new System.Drawing.Size(103, 52);
            this.btnADDproduct.TabIndex = 5;
            this.btnADDproduct.Text = "AddProducts";
            this.btnADDproduct.UseVisualStyleBackColor = true;
            this.btnADDproduct.Click += new System.EventHandler(this.btnADDproduct_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(641, 385);
            this.button2.Margin = new System.Windows.Forms.Padding(4);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(103, 62);
            this.button2.TabIndex = 6;
            this.button2.Text = "Update Product";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.Location = new System.Drawing.Point(641, 154);
            this.btnDelete.Margin = new System.Windows.Forms.Padding(4);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(103, 70);
            this.btnDelete.TabIndex = 7;
            this.btnDelete.Text = "Delete record";
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.button3_Click);
            // 
            // btnDataentryClose
            // 
            this.btnDataentryClose.Location = new System.Drawing.Point(641, 32);
            this.btnDataentryClose.Margin = new System.Windows.Forms.Padding(4);
            this.btnDataentryClose.Name = "btnDataentryClose";
            this.btnDataentryClose.Size = new System.Drawing.Size(103, 114);
            this.btnDataentryClose.TabIndex = 8;
            this.btnDataentryClose.Text = "Close Data Entry";
            this.btnDataentryClose.UseVisualStyleBackColor = true;
            this.btnDataentryClose.Click += new System.EventHandler(this.btnDataentryClose_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.button2);
            this.groupBox1.Controls.Add(this.dataGridView1);
            this.groupBox1.Controls.Add(this.btnADDproduct);
            this.groupBox1.Controls.Add(this.btnDelete);
            this.groupBox1.Controls.Add(this.txtProductqty);
            this.groupBox1.Controls.Add(this.btnDataentryClose);
            this.groupBox1.Controls.Add(this.txtProductprice);
            this.groupBox1.Controls.Add(this.txtproductname);
            this.groupBox1.Font = new System.Drawing.Font("Modern No. 20", 9.857142F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(814, 50);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox1.Size = new System.Drawing.Size(781, 479);
            this.groupBox1.TabIndex = 9;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Full products list";
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // label4
            // 
            this.label4.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.857143F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(324, 350);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(155, 59);
            this.label4.TabIndex = 11;
            this.label4.Text = "product qnty";
            // 
            // label3
            // 
            this.label3.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.857143F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(182, 344);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(136, 56);
            this.label3.TabIndex = 10;
            this.label3.Text = "price";
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.857143F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(32, 344);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(138, 56);
            this.label2.TabIndex = 9;
            this.label2.Text = "product name";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.btnCoke);
            this.groupBox2.Controls.Add(this.btnTea);
            this.groupBox2.Controls.Add(this.btnMilk);
            this.groupBox2.Controls.Add(this.btnPepsi);
            this.groupBox2.Controls.Add(this.btnFanta);
            this.groupBox2.Controls.Add(this.btnSprite);
            this.groupBox2.Controls.Add(this.btnDrpeper);
            this.groupBox2.Controls.Add(this.btn7up);
            this.groupBox2.Font = new System.Drawing.Font("Modern No. 20", 9.857142F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(16, 18);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox2.Size = new System.Drawing.Size(270, 606);
            this.groupBox2.TabIndex = 17;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Select your product";
            // 
            // btnCoke
            // 
            this.btnCoke.BackgroundImage = global::vendingMachine.Properties.Resources.coke;
            this.btnCoke.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnCoke.Location = new System.Drawing.Point(8, 32);
            this.btnCoke.Margin = new System.Windows.Forms.Padding(4);
            this.btnCoke.Name = "btnCoke";
            this.btnCoke.Size = new System.Drawing.Size(117, 134);
            this.btnCoke.TabIndex = 0;
            this.btnCoke.UseVisualStyleBackColor = true;
            this.btnCoke.Click += new System.EventHandler(this.btnCoke_Click);
            // 
            // btnTea
            // 
            this.btnTea.BackgroundImage = global::vendingMachine.Properties.Resources.pepsi;
            this.btnTea.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnTea.Location = new System.Drawing.Point(0, 459);
            this.btnTea.Margin = new System.Windows.Forms.Padding(4);
            this.btnTea.Name = "btnTea";
            this.btnTea.Size = new System.Drawing.Size(117, 134);
            this.btnTea.TabIndex = 15;
            this.btnTea.UseVisualStyleBackColor = true;
            this.btnTea.Click += new System.EventHandler(this.btnTea_Click);
            // 
            // btnMilk
            // 
            this.btnMilk.BackgroundImage = global::vendingMachine.Properties.Resources.fantastraw;
            this.btnMilk.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnMilk.Location = new System.Drawing.Point(133, 459);
            this.btnMilk.Margin = new System.Windows.Forms.Padding(4);
            this.btnMilk.Name = "btnMilk";
            this.btnMilk.Size = new System.Drawing.Size(117, 134);
            this.btnMilk.TabIndex = 16;
            this.btnMilk.UseVisualStyleBackColor = true;
            this.btnMilk.Click += new System.EventHandler(this.btnMilk_Click);
            // 
            // btnPepsi
            // 
            this.btnPepsi.BackgroundImage = global::vendingMachine.Properties.Resources.coke500ml;
            this.btnPepsi.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnPepsi.Location = new System.Drawing.Point(133, 32);
            this.btnPepsi.Margin = new System.Windows.Forms.Padding(4);
            this.btnPepsi.Name = "btnPepsi";
            this.btnPepsi.Size = new System.Drawing.Size(117, 134);
            this.btnPepsi.TabIndex = 10;
            this.btnPepsi.UseVisualStyleBackColor = true;
            this.btnPepsi.Click += new System.EventHandler(this.btnPepsi_Click);
            // 
            // btnFanta
            // 
            this.btnFanta.BackgroundImage = global::vendingMachine.Properties.Resources.fanta1;
            this.btnFanta.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnFanta.Location = new System.Drawing.Point(8, 174);
            this.btnFanta.Margin = new System.Windows.Forms.Padding(4);
            this.btnFanta.Name = "btnFanta";
            this.btnFanta.Size = new System.Drawing.Size(117, 134);
            this.btnFanta.TabIndex = 11;
            this.btnFanta.UseVisualStyleBackColor = true;
            this.btnFanta.Click += new System.EventHandler(this.btnFanta_Click);
            // 
            // btnSprite
            // 
            this.btnSprite.BackgroundImage = global::vendingMachine.Properties.Resources._7up;
            this.btnSprite.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnSprite.Location = new System.Drawing.Point(0, 316);
            this.btnSprite.Margin = new System.Windows.Forms.Padding(4);
            this.btnSprite.Name = "btnSprite";
            this.btnSprite.Size = new System.Drawing.Size(117, 134);
            this.btnSprite.TabIndex = 13;
            this.btnSprite.UseVisualStyleBackColor = true;
            this.btnSprite.Click += new System.EventHandler(this.btnSprite_Click);
            // 
            // btnDrpeper
            // 
            this.btnDrpeper.BackgroundImage = global::vendingMachine.Properties.Resources.bottle;
            this.btnDrpeper.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnDrpeper.Location = new System.Drawing.Point(133, 316);
            this.btnDrpeper.Margin = new System.Windows.Forms.Padding(4);
            this.btnDrpeper.Name = "btnDrpeper";
            this.btnDrpeper.Size = new System.Drawing.Size(117, 134);
            this.btnDrpeper.TabIndex = 14;
            this.btnDrpeper.UseVisualStyleBackColor = true;
            this.btnDrpeper.Click += new System.EventHandler(this.btnDrpeper_Click);
            // 
            // btn7up
            // 
            this.btn7up.BackgroundImage = global::vendingMachine.Properties.Resources.fanta;
            this.btn7up.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn7up.Location = new System.Drawing.Point(133, 174);
            this.btn7up.Margin = new System.Windows.Forms.Padding(4);
            this.btn7up.Name = "btn7up";
            this.btn7up.Size = new System.Drawing.Size(117, 134);
            this.btn7up.TabIndex = 12;
            this.btn7up.UseVisualStyleBackColor = true;
            this.btn7up.Click += new System.EventHandler(this.btn7up_Click);
            // 
            // txtPassword
            // 
            this.txtPassword.Location = new System.Drawing.Point(16, 709);
            this.txtPassword.Margin = new System.Windows.Forms.Padding(4);
            this.txtPassword.Name = "txtPassword";
            this.txtPassword.Size = new System.Drawing.Size(139, 29);
            this.txtPassword.TabIndex = 18;
            this.txtPassword.Text = "Admin";
            // 
            // button10
            // 
            this.button10.Location = new System.Drawing.Point(12, 746);
            this.button10.Margin = new System.Windows.Forms.Padding(4);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(262, 78);
            this.button10.TabIndex = 19;
            this.button10.Text = "Login to dataEntry";
            this.button10.UseVisualStyleBackColor = true;
            this.button10.Click += new System.EventHandler(this.button10_Click);
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Location = new System.Drawing.Point(137, 709);
            this.checkBox1.Margin = new System.Windows.Forms.Padding(4);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(167, 29);
            this.checkBox1.TabIndex = 20;
            this.checkBox1.Text = "Hide password";
            this.checkBox1.UseVisualStyleBackColor = true;
            this.checkBox1.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label1.Font = new System.Drawing.Font("Modern No. 20", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(25, 634);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(260, 65);
            this.label1.TabIndex = 21;
            this.label1.Text = "Admin login  to data entry";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.btnPrdcancel);
            this.groupBox3.Controls.Add(this.btnBuyprd);
            this.groupBox3.Controls.Add(this.lblProdQty);
            this.groupBox3.Controls.Add(this.lblProdPrice);
            this.groupBox3.Controls.Add(this.lblProdName);
            this.groupBox3.Font = new System.Drawing.Font("Lucida Console", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox3.Location = new System.Drawing.Point(294, 32);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(483, 454);
            this.groupBox3.TabIndex = 22;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Your selection";
            // 
            // btnPrdcancel
            // 
            this.btnPrdcancel.Location = new System.Drawing.Point(13, 392);
            this.btnPrdcancel.Name = "btnPrdcancel";
            this.btnPrdcancel.Size = new System.Drawing.Size(353, 44);
            this.btnPrdcancel.TabIndex = 26;
            this.btnPrdcancel.Text = "CANCEL";
            this.btnPrdcancel.UseVisualStyleBackColor = true;
            this.btnPrdcancel.Click += new System.EventHandler(this.btnPrdcancel_Click);
            // 
            // btnBuyprd
            // 
            this.btnBuyprd.Location = new System.Drawing.Point(13, 326);
            this.btnBuyprd.Name = "btnBuyprd";
            this.btnBuyprd.Size = new System.Drawing.Size(353, 44);
            this.btnBuyprd.TabIndex = 25;
            this.btnBuyprd.Text = "Make payment";
            this.btnBuyprd.UseVisualStyleBackColor = true;
            this.btnBuyprd.Click += new System.EventHandler(this.btnBuyprd_Click);
            // 
            // lblProdQty
            // 
            this.lblProdQty.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lblProdQty.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblProdQty.Font = new System.Drawing.Font("Modern No. 20", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProdQty.Location = new System.Drawing.Point(7, 242);
            this.lblProdQty.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblProdQty.Name = "lblProdQty";
            this.lblProdQty.Size = new System.Drawing.Size(425, 52);
            this.lblProdQty.TabIndex = 24;
            // 
            // lblProdPrice
            // 
            this.lblProdPrice.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lblProdPrice.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblProdPrice.Font = new System.Drawing.Font("Modern No. 20", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProdPrice.Location = new System.Drawing.Point(7, 154);
            this.lblProdPrice.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblProdPrice.Name = "lblProdPrice";
            this.lblProdPrice.Size = new System.Drawing.Size(425, 75);
            this.lblProdPrice.TabIndex = 23;
            // 
            // lblProdName
            // 
            this.lblProdName.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lblProdName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblProdName.Font = new System.Drawing.Font("Modern No. 20", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProdName.Location = new System.Drawing.Point(7, 80);
            this.lblProdName.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblProdName.Name = "lblProdName";
            this.lblProdName.Size = new System.Drawing.Size(425, 48);
            this.lblProdName.TabIndex = 22;
            // 
            // groupBoxSerializaiton
            // 
            this.groupBoxSerializaiton.Controls.Add(this.btn_BINARY_DESERILZ);
            this.groupBoxSerializaiton.Controls.Add(this.btnBINARY_serialization);
            this.groupBoxSerializaiton.Controls.Add(this.button3);
            this.groupBoxSerializaiton.Controls.Add(this.button1);
            this.groupBoxSerializaiton.Location = new System.Drawing.Point(294, 494);
            this.groupBoxSerializaiton.Name = "groupBoxSerializaiton";
            this.groupBoxSerializaiton.Size = new System.Drawing.Size(483, 294);
            this.groupBoxSerializaiton.TabIndex = 23;
            this.groupBoxSerializaiton.TabStop = false;
            // 
            // btn_BINARY_DESERILZ
            // 
            this.btn_BINARY_DESERILZ.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.857143F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_BINARY_DESERILZ.Location = new System.Drawing.Point(27, 222);
            this.btn_BINARY_DESERILZ.Name = "btn_BINARY_DESERILZ";
            this.btn_BINARY_DESERILZ.Size = new System.Drawing.Size(420, 50);
            this.btn_BINARY_DESERILZ.TabIndex = 3;
            this.btn_BINARY_DESERILZ.Text = "PRODUCTS_BINARY_deserilization";
            this.btn_BINARY_DESERILZ.UseVisualStyleBackColor = true;
            this.btn_BINARY_DESERILZ.Click += new System.EventHandler(this.btn_BINARY_DESERILZ_Click);
            // 
            // btnBINARY_serialization
            // 
            this.btnBINARY_serialization.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.857143F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBINARY_serialization.Location = new System.Drawing.Point(27, 155);
            this.btnBINARY_serialization.Name = "btnBINARY_serialization";
            this.btnBINARY_serialization.Size = new System.Drawing.Size(420, 50);
            this.btnBINARY_serialization.TabIndex = 2;
            this.btnBINARY_serialization.Text = "PRODUCT_BINARY_serialization";
            this.btnBINARY_serialization.UseVisualStyleBackColor = true;
            this.btnBINARY_serialization.Click += new System.EventHandler(this.btnBINARY_serialization_Click);
            // 
            // button3
            // 
            this.button3.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.857143F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.Location = new System.Drawing.Point(27, 91);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(420, 43);
            this.button3.TabIndex = 1;
            this.button3.Text = "PRODUCTS_SOAP_deserialization";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click_1);
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.857143F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(27, 29);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(420, 42);
            this.button1.TabIndex = 0;
            this.button1.Text = "PRODUCTS_SOAP_serialization";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnBinaryDeserialization
            // 
            this.btnBinaryDeserialization.Font = new System.Drawing.Font("Arial Rounded MT Bold", 8.142858F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBinaryDeserialization.Location = new System.Drawing.Point(6, 131);
            this.btnBinaryDeserialization.Name = "btnBinaryDeserialization";
            this.btnBinaryDeserialization.Size = new System.Drawing.Size(434, 62);
            this.btnBinaryDeserialization.TabIndex = 3;
            this.btnBinaryDeserialization.Text = "COINS_BINARY DESERIALIZATION";
            this.btnBinaryDeserialization.UseVisualStyleBackColor = true;
            this.btnBinaryDeserialization.Click += new System.EventHandler(this.btnBinaryDeserialization_Click);
            // 
            // btnBInarySerialization
            // 
            this.btnBInarySerialization.Font = new System.Drawing.Font("Arial Rounded MT Bold", 8.142858F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBInarySerialization.Location = new System.Drawing.Point(4, 43);
            this.btnBInarySerialization.Name = "btnBInarySerialization";
            this.btnBInarySerialization.Size = new System.Drawing.Size(436, 69);
            this.btnBInarySerialization.TabIndex = 2;
            this.btnBInarySerialization.Text = "COINS_BINARY_SERIALIZATION";
            this.btnBInarySerialization.UseVisualStyleBackColor = true;
            this.btnBInarySerialization.Click += new System.EventHandler(this.btnBInarySerialization_Click);
            // 
            // btnSortbyproduct
            // 
            this.btnSortbyproduct.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.857143F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSortbyproduct.Location = new System.Drawing.Point(6, 55);
            this.btnSortbyproduct.Name = "btnSortbyproduct";
            this.btnSortbyproduct.Size = new System.Drawing.Size(263, 38);
            this.btnSortbyproduct.TabIndex = 24;
            this.btnSortbyproduct.Text = "sort by PRODUCT NAME";
            this.btnSortbyproduct.UseVisualStyleBackColor = true;
            this.btnSortbyproduct.Click += new System.EventHandler(this.btnSortbyqty_Click);
            // 
            // grpboxCoins
            // 
            this.grpboxCoins.Controls.Add(this.label6);
            this.grpboxCoins.Controls.Add(this.button4);
            this.grpboxCoins.Controls.Add(this.btnconfirmbuy);
            this.grpboxCoins.Controls.Add(this.coins);
            this.grpboxCoins.Controls.Add(this.lblCoinsTotal);
            this.grpboxCoins.Controls.Add(this.button9);
            this.grpboxCoins.Controls.Add(this.btnTotal);
            this.grpboxCoins.Controls.Add(this.button8);
            this.grpboxCoins.Controls.Add(this.btnOnepound);
            this.grpboxCoins.Controls.Add(this.button6);
            this.grpboxCoins.Controls.Add(this.button5);
            this.grpboxCoins.Controls.Add(this.btnFivepence);
            this.grpboxCoins.Location = new System.Drawing.Point(814, 536);
            this.grpboxCoins.Name = "grpboxCoins";
            this.grpboxCoins.Size = new System.Drawing.Size(815, 461);
            this.grpboxCoins.TabIndex = 9;
            this.grpboxCoins.TabStop = false;
            this.grpboxCoins.Text = "select coins";
            // 
            // label6
            // 
            this.label6.Location = new System.Drawing.Point(589, 60);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(192, 39);
            this.label6.TabIndex = 29;
            this.label6.Text = "Coins inserted";
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(439, 311);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(163, 65);
            this.button4.TabIndex = 26;
            this.button4.Text = "button4";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // btnconfirmbuy
            // 
            this.btnconfirmbuy.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnconfirmbuy.Font = new System.Drawing.Font("Modern No. 20", 14.14286F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnconfirmbuy.Location = new System.Drawing.Point(38, 311);
            this.btnconfirmbuy.Name = "btnconfirmbuy";
            this.btnconfirmbuy.Size = new System.Drawing.Size(395, 65);
            this.btnconfirmbuy.TabIndex = 28;
            this.btnconfirmbuy.Text = "buy poduct";
            this.btnconfirmbuy.UseVisualStyleBackColor = true;
            this.btnconfirmbuy.Click += new System.EventHandler(this.btnconfirmbuy_Click);
            // 
            // coins
            // 
            this.coins.FormattingEnabled = true;
            this.coins.ItemHeight = 24;
            this.coins.Location = new System.Drawing.Point(589, 109);
            this.coins.Name = "coins";
            this.coins.Size = new System.Drawing.Size(192, 196);
            this.coins.TabIndex = 25;
            // 
            // lblCoinsTotal
            // 
            this.lblCoinsTotal.Location = new System.Drawing.Point(644, 333);
            this.lblCoinsTotal.Name = "lblCoinsTotal";
            this.lblCoinsTotal.Size = new System.Drawing.Size(59, 37);
            this.lblCoinsTotal.TabIndex = 27;
            this.lblCoinsTotal.Text = "Total";
            // 
            // button9
            // 
            this.button9.BackgroundImage = global::vendingMachine.Properties.Resources._30198;
            this.button9.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button9.Location = new System.Drawing.Point(37, 128);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(546, 177);
            this.button9.TabIndex = 5;
            this.button9.Text = "button9";
            this.button9.UseVisualStyleBackColor = true;
            // 
            // btnTotal
            // 
            this.btnTotal.Location = new System.Drawing.Point(709, 298);
            this.btnTotal.Name = "btnTotal";
            this.btnTotal.Size = new System.Drawing.Size(142, 72);
            this.btnTotal.TabIndex = 26;
            this.btnTotal.UseVisualStyleBackColor = true;
            // 
            // button8
            // 
            this.button8.Location = new System.Drawing.Point(456, 35);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(127, 90);
            this.button8.TabIndex = 4;
            this.button8.UseVisualStyleBackColor = true;
            // 
            // btnOnepound
            // 
            this.btnOnepound.BackgroundImage = global::vendingMachine.Properties.Resources.nintchdbpict000292059573;
            this.btnOnepound.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnOnepound.Location = new System.Drawing.Point(362, 35);
            this.btnOnepound.Name = "btnOnepound";
            this.btnOnepound.Size = new System.Drawing.Size(96, 90);
            this.btnOnepound.TabIndex = 3;
            this.btnOnepound.UseVisualStyleBackColor = true;
            this.btnOnepound.Click += new System.EventHandler(this.btnOnepound_Click);
            // 
            // button6
            // 
            this.button6.BackgroundImage = global::vendingMachine.Properties.Resources.g86;
            this.button6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button6.Location = new System.Drawing.Point(257, 35);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(99, 90);
            this.button6.TabIndex = 2;
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // button5
            // 
            this.button5.BackgroundImage = global::vendingMachine.Properties.Resources._20_pence_coin_ay8p35;
            this.button5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button5.Location = new System.Drawing.Point(151, 32);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(100, 97);
            this.button5.TabIndex = 1;
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // btnFivepence
            // 
            this.btnFivepence.BackgroundImage = global::vendingMachine.Properties.Resources._5p;
            this.btnFivepence.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnFivepence.Location = new System.Drawing.Point(33, 35);
            this.btnFivepence.Name = "btnFivepence";
            this.btnFivepence.Size = new System.Drawing.Size(112, 97);
            this.btnFivepence.TabIndex = 0;
            this.btnFivepence.UseVisualStyleBackColor = true;
            this.btnFivepence.Click += new System.EventHandler(this.btnFivepence_Click);
            // 
            // btnReset
            // 
            this.btnReset.ForeColor = System.Drawing.Color.OrangeRed;
            this.btnReset.Location = new System.Drawing.Point(1638, 545);
            this.btnReset.Name = "btnReset";
            this.btnReset.Size = new System.Drawing.Size(175, 90);
            this.btnReset.TabIndex = 6;
            this.btnReset.Text = " Reset the machine";
            this.btnReset.UseVisualStyleBackColor = true;
            this.btnReset.Click += new System.EventHandler(this.btnReset_Click);
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.btnBInarySerialization);
            this.groupBox4.Controls.Add(this.btnBinaryDeserialization);
            this.groupBox4.Font = new System.Drawing.Font("Modern No. 20", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox4.Location = new System.Drawing.Point(301, 804);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(476, 199);
            this.groupBox4.TabIndex = 25;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "COINS CURRENT STATUS";
            // 
            // grpsorting
            // 
            this.grpsorting.Controls.Add(this.btnSortbyqty);
            this.grpsorting.Controls.Add(this.btnSortbyproduct);
            this.grpsorting.Font = new System.Drawing.Font("Modern No. 20", 9.857142F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpsorting.Location = new System.Drawing.Point(7, 834);
            this.grpsorting.Name = "grpsorting";
            this.grpsorting.Size = new System.Drawing.Size(279, 173);
            this.grpsorting.TabIndex = 26;
            this.grpsorting.TabStop = false;
            this.grpsorting.Text = "SORTING ";
            // 
            // btnSortbyqty
            // 
            this.btnSortbyqty.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.857143F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSortbyqty.Location = new System.Drawing.Point(6, 118);
            this.btnSortbyqty.Name = "btnSortbyqty";
            this.btnSortbyqty.Size = new System.Drawing.Size(261, 38);
            this.btnSortbyqty.TabIndex = 25;
            this.btnSortbyqty.Text = "sort by QTY";
            this.btnSortbyqty.UseVisualStyleBackColor = true;
            this.btnSortbyqty.Click += new System.EventHandler(this.btnSortbyqty_Click_1);
            // 
            // lblTotalQnty
            // 
            this.lblTotalQnty.Location = new System.Drawing.Point(1614, 450);
            this.lblTotalQnty.Name = "lblTotalQnty";
            this.lblTotalQnty.Size = new System.Drawing.Size(124, 36);
            this.lblTotalQnty.TabIndex = 27;
            this.lblTotalQnty.Text = "Total QNTY";
            // 
            // btnTotalQnty
            // 
            this.btnTotalQnty.Location = new System.Drawing.Point(1757, 445);
            this.btnTotalQnty.Name = "btnTotalQnty";
            this.btnTotalQnty.Size = new System.Drawing.Size(135, 45);
            this.btnTotalQnty.TabIndex = 28;
            this.btnTotalQnty.UseVisualStyleBackColor = true;
            // 
            // btnnewtotal
            // 
            this.btnnewtotal.Location = new System.Drawing.Point(1602, 93);
            this.btnnewtotal.Name = "btnnewtotal";
            this.btnnewtotal.Size = new System.Drawing.Size(264, 67);
            this.btnnewtotal.TabIndex = 29;
            this.btnnewtotal.UseVisualStyleBackColor = true;
            this.btnnewtotal.Click += new System.EventHandler(this.btnnewtotal_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(1603, 69);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(225, 25);
            this.label5.TabIndex = 30;
            this.label5.Text = "Current STOCK VALUE";
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(1602, 180);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(281, 46);
            this.button7.TabIndex = 32;
            this.button7.Text = "view stock report";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // printPreviewDialog1
            // 
            this.printPreviewDialog1.AutoScrollMargin = new System.Drawing.Size(0, 0);
            this.printPreviewDialog1.AutoScrollMinSize = new System.Drawing.Size(0, 0);
            this.printPreviewDialog1.ClientSize = new System.Drawing.Size(400, 300);
            this.printPreviewDialog1.Enabled = true;
            this.printPreviewDialog1.Icon = ((System.Drawing.Icon)(resources.GetObject("printPreviewDialog1.Icon")));
            this.printPreviewDialog1.Name = "printPreviewDialog1";
            this.printPreviewDialog1.Visible = false;
            this.printPreviewDialog1.Load += new System.EventHandler(this.printPreviewDialog1_Load);
            // 
            // dataGridView2
            // 
            this.dataGridView2.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dataGridView2.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Column2});
            this.dataGridView2.Location = new System.Drawing.Point(1608, 232);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.RowTemplate.Height = 31;
            this.dataGridView2.Size = new System.Drawing.Size(284, 207);
            this.dataGridView2.TabIndex = 33;
            // 
            // Column1
            // 
            this.Column1.HeaderText = "product";
            this.Column1.Name = "Column1";
            this.Column1.Width = 118;
            // 
            // Column2
            // 
            this.Column2.HeaderText = "qty";
            this.Column2.Name = "Column2";
            this.Column2.Width = 79;
            // 
            // Form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(11F, 24F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1924, 1044);
            this.Controls.Add(this.dataGridView2);
            this.Controls.Add(this.button7);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.btnnewtotal);
            this.Controls.Add(this.btnTotalQnty);
            this.Controls.Add(this.lblTotalQnty);
            this.Controls.Add(this.grpsorting);
            this.Controls.Add(this.btnReset);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.grpboxCoins);
            this.Controls.Add(this.groupBoxSerializaiton);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.checkBox1);
            this.Controls.Add(this.button10);
            this.Controls.Add(this.txtPassword);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Form";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBoxSerializaiton.ResumeLayout(false);
            this.grpboxCoins.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.grpsorting.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnCoke;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.TextBox txtproductname;
        private System.Windows.Forms.TextBox txtProductprice;
        private System.Windows.Forms.TextBox txtProductqty;
        private System.Windows.Forms.Button btnADDproduct;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Button btnDataentryClose;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btnPepsi;
        private System.Windows.Forms.Button btnFanta;
        private System.Windows.Forms.Button btn7up;
        private System.Windows.Forms.Button btnSprite;
        private System.Windows.Forms.Button btnDrpeper;
        private System.Windows.Forms.Button btnTea;
        private System.Windows.Forms.Button btnMilk;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox txtPassword;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button btnPrdcancel;
        private System.Windows.Forms.Button btnBuyprd;
        private System.Windows.Forms.Label lblProdQty;
        private System.Windows.Forms.Label lblProdPrice;
        private System.Windows.Forms.Label lblProdName;
        private System.Windows.Forms.GroupBox groupBoxSerializaiton;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button btnSortbyproduct;
        private System.Windows.Forms.GroupBox grpboxCoins;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button btnFivepence;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button btnOnepound;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button btnReset;
        private System.Windows.Forms.ListBox coins;
        private System.Windows.Forms.Button btnTotal;
        private System.Windows.Forms.Label lblCoinsTotal;
        private System.Windows.Forms.Button btnBinaryDeserialization;
        private System.Windows.Forms.Button btnBInarySerialization;
        private System.Windows.Forms.Button btnconfirmbuy;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btn_BINARY_DESERILZ;
        private System.Windows.Forms.Button btnBINARY_serialization;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.GroupBox grpsorting;
        private System.Windows.Forms.Button btnSortbyqty;
        private System.Windows.Forms.Label lblTotalQnty;
        private System.Windows.Forms.Button btnTotalQnty;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button btnnewtotal;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.PrintPreviewDialog printPreviewDialog1;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
    }
}

