﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ladiesitems.Admin
{
    public partial class Login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnLOGIN_Click(object sender, EventArgs e)
        {
            String LoginId = WebConfigurationManager.AppSettings["AdminLoginId"];
            string Password = WebConfigurationManager.AppSettings["AdminPassword"];

            if (txtLoginId.Text == LoginId && txtLoginPassword.Text == Password)
            {
                Session["Ladiesitemsadmin"] = "Ladiesitemadmin";
                Response.Redirect("~/Admin/Addnewproducts.aspx");

            }
            else
            {
                lblerror.Text = "InCorrect user name or password";
            }
        }
    }
}