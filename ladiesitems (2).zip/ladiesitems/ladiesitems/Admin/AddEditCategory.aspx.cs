﻿using System;
using System.Collections.Generic;
using System.Drawing.Design;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ladiesitems.BusinessLayer;

namespace ladiesitems.Admin
{
    public partial class AddEditCategory : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void lblSubmit_Click(object sender, EventArgs e)
        {
            ShoppingCart k = new ShoppingCart
            {

                CategoryName =TextBox1.Text
            };
            k.AddnnewCategory();
            TextBox1.Text = String.Empty;
            Response.Redirect("~/Admin/AddnewProducts.aspx");
        }
    }
}