﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ladiesitems.BusinessLayer;
using ladiesitems.DataLayer;
using System.IO;
using System.Collections.Generic;

namespace ladiesitems.Admin
{
    public partial class AddnewProducts : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                GetCategories();


            }
                    
                
        }

        private void GetCategories()
        {

            ShoppingCart k=new ShoppingCart();
            DataTable dt = k.GetCategories();
            if (dt.Rows.Count > 0)
            {
                ddlCategory.DataValueField = "CategoryID";
                ddlCategory.DataTextField = "CategoryName";
                ddlCategory.DataSource = dt;
                ddlCategory.DataBind();


            }


        }

        protected void btnproductSUBMIT_Click(object sender, EventArgs e)
        {
            if (uploadedProductPhoto.PostedFile != null)
            {
                SaveProductPhoto();

                ShoppingCart k = new ShoppingCart()
                {
                    productname = txtproductname.Text,
                    productimage = "~/productImages/" + uploadedProductPhoto.FileName,
                    productprice = txtunitprice.Text,
                    productdescription = txtproductdescription.Text,
                   
                    CategoryID = Convert.ToInt32(ddlCategory.SelectedValue),
                    productquantity = Convert.ToInt32(txtquantity.Text),
                    
         
                };
                
                k.AddNewProduct();
               // ClearText();

            }
        }

        private void SaveProductPhoto()
        {

            if (uploadedProductPhoto.PostedFile != null)
            {
                //String filename= uploadedProductPhoto.PostedFile.FileName.ToString();

                string filename = Path.GetFileName(uploadedProductPhoto.FileName);
                 

                String fileExt = System.IO.Path.GetExtension(uploadedProductPhoto.FileName);

              

                if (filename.Length > 96)
                {

                }
                else if (fileExt != ".jpeg" && fileExt != ".jpg" && fileExt != ".png" && fileExt != ".bmp")
                {

                }
                else if (uploadedProductPhoto.PostedFile.ContentLength > 400000)
                {


                }
                else
                {
                    string filename1 = Path.GetFileName(uploadedProductPhoto.FileName);
                   uploadedProductPhoto.SaveAs(Server.MapPath("~/productimages/") + filename1);
                    //StatusLabel.Text = "Upload status: File uploaded!";

                   // uploadedProductPhoto.SaveAs(Server.MapPath("~/productImages/" + filename1);
                }

            }


        }
        

    }
}