﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Data;

namespace ladiesitems.BusinessLayer
{
    public class ShoppingCart
    {

        public string CategoryName;
        public int CategoryID;
        public int ProductID;
        public int CsutomerID;
        


        public string productname;
        public string productimage;
        public string productprice;
        public string productdescription;
        public int productquantity;

        public string CustomerName;
        public string CustomerEmailID;
        public string CustomerPhoneNo;
        public string CustomerAddress;
        public string ProductList;
        public string PaymentMethod;

        public string OrderStatus;
        public string Orders;

        public int TotalProducts;
        public int TotalPrice;
        public int StockType;
        public int Flag;





        public void AddnnewCategory()
        {
            SqlParameter[] parameters=new SqlParameter[1];
            parameters[0] =
                DataLayer.DataAccess.AParameter("@CategoryName", CategoryName, System.Data.SqlDbType.VarChar, 200);
            DataTable dt = DataLayer.DataAccess.ExecuteDtByprocedure("SP_AddNewCategory", parameters);


        }
        public DataTable GetCategories()
        {

            SqlParameter[] parameters = new SqlParameter[0];
            DataTable dt = DataLayer.DataAccess.ExecuteDtByprocedure("SP_GetAllcategories", parameters);
            return dt;


        }


        public DataTable GetAllProducts()
        {
            SqlParameter[] parameters=new SqlParameter[1];
            parameters[0] = DataLayer.DataAccess.AParameter("@CategoryID", CategoryID, System.Data.SqlDbType.Int, 20);
            DataTable dt = DataLayer.DataAccess.ExecuteDtByprocedure("SP_GetAllProducts", parameters);
            return dt;


        }
            
            



        

        public void AddNewProduct()
        {

            SqlParameter[] parameters=new SqlParameter[6];
            parameters[0] = DataLayer.DataAccess.AParameter("@productname",productname, System.Data.SqlDbType.VarChar, 300);
           // parameters[0] =DataLayer.DataAccess.AParameter("@p_name", p_name, System.Data.SqlDbType.VarChar, 300);

            
            parameters[1] =
                DataLayer.DataAccess.AParameter("@productprice", productprice, System.Data.SqlDbType.Int, 100);
            parameters[2] =
                DataLayer.DataAccess.AParameter("@productImage", productimage, System.Data.SqlDbType.VarChar, 500);
            parameters[3] = DataLayer.DataAccess.AParameter("@productdescription", productdescription,
                System.Data.SqlDbType.VarChar, 1000);
            parameters[4] = DataLayer.DataAccess.AParameter("@categoryID",CategoryID,System.Data.SqlDbType.Int,100);

            parameters[5] =
                DataLayer.DataAccess.AParameter("@productquanity", productquantity, System.Data.SqlDbType.Int, 100);
            DataTable dt = DataLayer.DataAccess.ExecuteDtByprocedure("SP_AddNewProduct", parameters);


        }
       
    }
}