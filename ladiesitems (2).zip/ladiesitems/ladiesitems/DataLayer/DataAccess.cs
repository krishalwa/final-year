﻿using System;
using System.CodeDom;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace ladiesitems.DataLayer
{
    public class DataAccess
    {

        public static string ConnectionString
        {
            get { return ConfigurationManager.ConnectionStrings["MyConn"].ConnectionString.ToString(); }


        }

        public static SqlParameter AParameter(string parameterName, object value, SqlDbType dbType, int size)
        {
            SqlParameter param = new SqlParameter();
            param.ParameterName = parameterName;
            param.Value = value.ToString();
            param.SqlDbType = dbType;
            param.Size = size;
            param.Direction = ParameterDirection.Input;
            return param;




        }

        public static DataTable ExecuteDtByprocedure(string procedurename, SqlParameter[] Params)
        {
            SqlConnection conn=new SqlConnection(ConnectionString);
            SqlCommand cmd=new SqlCommand();
            cmd.Connection = conn;
            cmd.CommandText = procedurename;
            cmd.Parameters.AddRange(Params);
            cmd.CommandType = CommandType.StoredProcedure;
            SqlDataAdapter adopter=new SqlDataAdapter(cmd);
            DataTable dtable=new DataTable();

            try
            {
                adopter.Fill(dtable);
            }

            catch (Exception ex)
            {
                //StatusLabel.Text = "Upload status: The file could not be uploaded. The following error occured: " + ex.Message;

            }
            finally
            {
                adopter.Dispose();
                cmd.Parameters.Clear();
                cmd.Dispose();
                conn.Dispose();


            }

            return dtable;
        }

    }
}