﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ladiesitems.DataLayer;
using ladiesitems.BusinessLayer;
using ladiesitems.DataLayer;
using System.Data.SqlClient;
using System.Web.Configuration;
using System.Web.Services.Protocols;
using System.Web.UI.WebControls;

namespace ladiesitems
{
    public partial class Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                lblCategoryName.Text = "popurlar products  fast moving items";
                GetCategory();

                GetProducts(0);
                lblAvailableStockAlert.Text = string.Empty;
            }

        }

        private void GetCategory()
        {
            ShoppingCart k = new ShoppingCart();
            dlCategories.DataSource = null;
            dlCategories.DataSource = k.GetCategories();
            dlCategories.DataBind();



        }

        private void GetProducts(int CategoryID)
        {
            ShoppingCart k = new ShoppingCart()
            {
                CategoryID = CategoryID

            };
            dlProducts.DataSource = null;
            dlProducts.DataSource = k.GetAllProducts();
            dlProducts.DataBind();


        }

        protected void Button1_Click(object sender, EventArgs e)
        {

        }

        protected void LinkButton3_Click(object sender, EventArgs e)
        {
           



        }

        protected void lbtnCategory_click(object sender, EventArgs e)
        {
            pnlMyCart.Visible = false;
            pnlProducts.Visible = true;
            int CategoryID = Convert.ToInt16((((LinkButton) sender).CommandArgument));
            GetProducts(CategoryID);
            HighlightCartProduct();


        }

        protected void btnAddToCart_click(object sender, EventArgs e)
        {
            String ProductID = Convert.ToInt16((((Button)sender).CommandArgument)).ToString();
            string ProductQuantity = "1";

            DataListItem currentItem = (sender as Button).NamingContainer as DataListItem;
            Label lblAvailableStock = currentItem.FindControl("lblAvailableStock") as Label;

            if (Session["MyCart"] != null)
            {
                DataTable dt = (DataTable) Session["MyCart"];

                var checkProduct = dt.AsEnumerable().Where(r => r.Field<string>("productID") == ProductID);
                if (checkProduct.Count() == 0)
                {
                    String Query = "select * from products where ProductID=" + ProductID + "";
                    DataTable dtproducts = GetData(Query);

                    DataRow dr = dt.NewRow();
                    dr["ProductID"] = ProductID;
                    dr["Name"] = Convert.ToString(dtproducts.Rows[0]["name"]);
                    dr["Description"] = Convert.ToString(dtproducts.Rows[0]["Description"]);
                    dr["price"] = Convert.ToString(dtproducts.Rows[0]["Price"]);
                    dr["imageurl"] = Convert.ToString(dtproducts.Rows[0]["ImageUrl"]);
                    dr["ProductQuantity"] = ProductQuantity;
                    dr["AvailableStock"] = lblAvailableStock.Text;
                    dt.Rows.Add(dr);
                    Session["MyCart"] = dt;
                    btnShoppingCart.Text = dt.Rows.Count.ToString();

                }

            }
            else
            {
                String Query = "select * from products where ProductID=" + ProductID + "";
                DataTable dtproducts = GetData(Query);
                DataTable dt = new DataTable();

                dt.Columns.Add("ProductID", typeof(string));
                dt.Columns.Add("Name", typeof(String));
                dt.Columns.Add("Description", typeof(string));
                dt.Columns.Add("Price", typeof(string));
                dt.Columns.Add("ImageUrl", typeof(string));
                dt.Columns.Add("ProductQuantity", typeof(string));
                dt.Columns.Add("AvailableStock", typeof(string));
                
                DataRow dr = dt.NewRow();
                dr["ProductID"] = ProductID;
                dr["Name"] = Convert.ToString(dtproducts.Rows[0]["name"]);
                dr["Description"] = Convert.ToString(dtproducts.Rows[0]["Description"]);
                dr["price"] = Convert.ToString(dtproducts.Rows[0]["Price"]);
                dr["imageurl"] = Convert.ToString(dtproducts.Rows[0]["ImageUrl"]);
                dr["ProductQuantity"] = ProductQuantity;
                dr["AvailableStock"] = lblAvailableStock.Text;
                dt.Rows.Add(dr);
                Session["MyCart"] = dt;
                btnShoppingCart.Text = dt.Rows.Count.ToString();  
 
            }

        }
        // String ProductID = Convert.ToInt16((((Button) sender).CommandArgument)).ToString();
           // string ProductQuantity = "1";

           // DataListItem currentItem = (sender as Button).NamingContainer as DataListItem;
           // Label lblAvailableStock = currentItem.FindControl("lblAvailableStock") as Label;

           // if (Session["MyCart"] != null)
          //  {
           // }
            //  DataTable dt = (DataTable) Session["MyCart"];

              //  var checkProduct = dt.AsEnumerable().Where(r => r.Field<string>("productID") == ProductID);
               // if (checkProduct.Count() == 0)
               // {
                  //  String Query = "select * from products where ProductID=" + ProductID + "";
                 //   DataTable dtproducts = GetData(Query);
                  //  DataRow dr = dt.NewRow();
                  //  dr["ProductID"] = ProductID;
                  //  dr["Name"] = Convert.ToString(dtproducts.Rows[0]["name"]);
                  //  dr["Descritipton"] = Convert.ToString(dtproducts.Rows[0]["Description"]);
                  //  dr["price"] = Convert.ToString(dtproducts.Rows[0]["Price"]);
                  //  dr["ProductQuantity"] = ProductQuantity;
                  //  dr["AvailableStock"] = lblAvailableStock.Text;
                  //  dt.Rows.Add(dr);
                 //   Session["MyCart"] = dt;
                  //  btnShoppingCart.Text = dt.Rows.Count.ToString();

             //   }
           // }
           // else
            //{
             //   String Query = "select * from product where ProductID=" + ProductID + "";
             //   DataTable dtproducts = GetData(Query);

             //   DataTable dt = new DataTable();


              //  dt.Columns.Add("ProductID", typeof(string));
              //  dt.Columns.Add("Name", typeof(String));
              //  dt.Columns.Add("Description", typeof(string));
              //  dt.Columns.Add("Price", typeof(string));
             //   dt.Columns.Add("ImageUrl", typeof(string));
              //  dt.Columns.Add("ProductQuantity", typeof(string));
              //  dt.Columns.Add("AvailableStock", typeof(string));






             //   DataRow dr = dt.NewRow();
              //  dr["ProductID"] = ProductID;
              //  dr["Name"] = Convert.ToString(dtproducts.Rows[0]["name"]);
              //  dr["Descritipton"] = Convert.ToString(dtproducts.Rows[0]["Description"]);
             //   dr["price"] = Convert.ToString(dtproducts.Rows[0]["Price"]);
              //  dr["ProductQuantity"] = ProductQuantity;
              //  dr["AvailableStock"] = lblAvailableStock.Text;
              //  dt.Rows.Add(dr);
           //     Session["MyCart"] = dt;
              ////  btnShoppingCart.Text = dt.Rows.Count.ToString();



          // /// }

          // HighlightCartProduct();







        //}









        protected void txtProductQuantity_textChanged(object sender, EventArgs e)
        {
            TextBox txtQuantity = (sender as TextBox);
            DataListItem curreItem = (sender as TextBox).NamingContainer as DataListItem;
            HiddenField ProductID = curreItem.FindControl("htfProductID") as HiddenField;
            Label lblAvailablestock = curreItem.FindControl("lblAvailableStock") as Label;

            if (txtQuantity.Text == string.Empty || txtQuantity.Text == "0" || txtQuantity.Text == "1")
            {

                txtQuantity.Text = "1";

            }
            else
            {
                if (Session["MyCart"] != null)
                {
                    if (Convert.ToInt32(txtQuantity.Text) <= Convert.ToInt32(lblAvailablestock.Text))
                    {

                        DataTable dt = (DataTable) Session["MyCart"];
                        DataRow[] rows = dt.Select("ProductID='" + ProductID.Value + "'");
                        int index = dt.Rows.IndexOf(rows[0]);
                        dt.Rows[index]["ProductQuantity"] = txtQuantity.Text;
                        Session["MyCart"] = dt;

                    }
                    else
                    {
                        lblAvailablestock.Text = "Alert : Product Boyout should not be more available stock ";
                        txtQuantity.Text = "1";
                    }


                }

                
            }

            UpdateTototalBill();


        }

        private void HighlightCartProduct()
        {
            if (Session["MyCart"] != null)
            {
                
                
                DataTable dtProductsAddedToCart = (DataTable) Session["MyCart"];
                if (dtProductsAddedToCart.Rows.Count > 0)
                {
                    foreach (DataListItem item in dlProducts.Items)
                    {

                        try
                        {
                            HiddenField htfProductID = item.FindControl("htfProductID") as HiddenField;
                            if (dtProductsAddedToCart.AsEnumerable()
                                .Any(row => htfProductID.Value == row.Field<string>("productID"))) ;
                            {

                                Button btnAddtoCart = item.FindControl("btn_add_to_cart") as Button;
                                btnAddtoCart.BackColor = System.Drawing.Color.Green;
                                btnAddtoCart.Text = "Added to Cart";

                                Image imgGreenStar = item.FindControl("imgGreenStar") as Image;
                                imgGreenStar.Visible = true;


                            }
                        }
                        catch (Exception e)
                        {
                            Console.WriteLine(e);
                            throw;
                        }
                       

                    }



                }


            }


        }


        public DataTable GetData(String query)
        {
            DataTable dt = new DataTable();
            String conn = WebConfigurationManager.ConnectionStrings["MyConn"].ConnectionString;
            SqlConnection con = new SqlConnection(conn);
            con.Open();

            SqlDataAdapter da = new SqlDataAdapter(query, con);
            try
            {
                da.Fill(dt);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                throw;
            }
            
            con.Close();
            return dt;






        }


        protected void btnRemoveFromCart_click(object sender, EventArgs e)
        {
            String productID = Convert.ToInt16((((Button) sender).CommandArgument)).ToString();
            if(Session ["MyCart"]!=null )
            {
                DataTable dt = (DataTable) Session["MyCart"];
                DataRow drr = dt.Select("ProductID=" + productID + "").FirstOrDefault();
                if (drr != null)
                    dt.Rows.Remove(drr);
                Session["MyCart"] = dt;





            }
            GetMyCart();
        }

        protected void lbtnCategory_onclick(object sender, EventArgs e)
        {

        }

        protected void btnPlaceOrder_click(object sender, EventArgs e)
        {

        }

        private void UpdateTototalBill()
        {
            long TotalPrice = 0;
            long TotalProducts = 0;
            foreach (DataListItem item in dlCartProducts.Items)
            {
                Label PriceLabel = item.FindControl("lblPrice") as Label;
                TextBox  ProductQuantity=item .FindControl( "txtProductQuantity") as TextBox;
                long ProductPrice = Convert.ToInt64(PriceLabel.Text) * Convert.ToInt64(ProductQuantity.Text);
                TotalPrice = TotalPrice + ProductPrice;
                TotalProducts = TotalProducts + Convert.ToInt32(ProductQuantity.Text);



            }

            txtTotalPrice.Text = Convert.ToString(TotalPrice);
            txtTotalProduts.Text = Convert.ToString(TotalProducts);

        }

       

        protected void lblLogo_click(object sender, EventArgs e)
        {
            Response.Redirect("Default.aspx");
        }

        protected void btnAddToCart_Click1(object sender, EventArgs e)
        {

            String ProductID = Convert.ToInt16((((Button) sender).CommandArgument)).ToString();
            string ProductQuantity = "1";

           DataListItem currentItem = (sender as Button).NamingContainer as DataListItem;
            Label lblAvailableStock = currentItem.FindControl("lblAvailableStock") as Label;

            if (Session["MyCart"] != null)
            {
                DataTable dt = (DataTable)Session["MyCart"];

                var checkProduct = dt.AsEnumerable().Where(r => r.Field<string>("productID") == ProductID);
                if (checkProduct.Count() == 0)
                {
                    String Query = "select * from products where ProductID=" + ProductID + "";
                    DataTable dtproducts = GetData(Query);
                    DataRow dr = dt.NewRow();
                    dr["ProductID"] = ProductID;
                    dr["Name"] = Convert.ToString(dtproducts.Rows[0]["name"]);
                    dr["Description"] = Convert.ToString(dtproducts.Rows[0]["Description"]);
                    dr["price"] = Convert.ToString(dtproducts.Rows[0]["Price"]);
                    dr["ImageUrl"] = Convert.ToString(dtproducts.Rows[0]["ImageUrl"]);
                    dr["ProductQuantity"] = ProductQuantity;
                    dr["AvailableStock"] = lblAvailableStock.Text;
                    dt.Rows.Add(dr);
                    Session["MyCart"] = dt;
                    btnShoppingCart.Text = dt.Rows.Count.ToString();

                }
            }

            else
            {
                

            }
           

            



        }

        protected void btn_ItemsToCard_Click(object sender, EventArgs e)
        {
            String ProductID = Convert.ToInt16((((Button) sender).CommandArgument)).ToString();
            string ProductQuantity = "1";

            DataListItem currentItem = (sender as Button).NamingContainer as DataListItem;
            Label lblAvailableStock = currentItem.FindControl("lblAvailableStock") as Label;



            if (Session["MyCart"] != null)
            {
                DataTable dt = (DataTable) Session["MyCart"];

                var checkProduct = dt.AsEnumerable().Where(r => r.Field<string>("productID") == ProductID);
                if (checkProduct.Count() == 0)
                {
                    String Query = "select * from products where ProductID=" + ProductID + "";
                    DataTable dtproducts = GetData(Query);
                    DataRow dr = dt.NewRow();
                    dr["ProductID"] = ProductID;
                    dr["Name"] = Convert.ToString(dtproducts.Rows[0]["name"]);
                    dr["Description"] = Convert.ToString(dtproducts.Rows[0]["Description"]);
                    dr["price"] = Convert.ToString(dtproducts.Rows[0]["Price"]);
                    dr["ImageUrl"] = Convert.ToString(dtproducts.Rows[0]["ImageUrl"]);
                    dr["ProductQuantity"] = ProductQuantity;
                    dr["AvailableStock"] = lblAvailableStock.Text;
                    dt.Rows.Add(dr);
                    Session["MyCart"] = dt;
                    btnShoppingCart.Text = dt.Rows.Count.ToString();

                }

            }

            else

                {
                    String Query = "select * from products where ProductID=" + ProductID + "";
                    DataTable dtproducts = GetData(Query);
                    DataTable dt = new DataTable();
                    dt.Columns.Add("ProductID", typeof(string));
                    dt.Columns.Add("Name", typeof(String));
                    dt.Columns.Add("Description", typeof(string));
                    dt.Columns.Add("Price", typeof(string));
                    dt.Columns.Add("ImageUrl", typeof(string));
                    dt.Columns.Add("ProductQuantity", typeof(string));
                    dt.Columns.Add("AvailableStock", typeof(string));
                    DataRow dr = dt.NewRow();
                    dr["ProductID"] = ProductID;
                    dr["Name"] = Convert.ToString(dtproducts.Rows[0]["name"]);
                    dr["Description"] = Convert.ToString(dtproducts.Rows[0]["Description"]);
                    dr["price"] = Convert.ToString(dtproducts.Rows[0]["Price"]);
                    dr["ImageUrl"] = Convert.ToString(dtproducts.Rows[0]["ImageUrl"]);
                    dr["ProductQuantity"] = ProductQuantity;
                    dr["AvailableStock"] = lblAvailableStock.Text;
                    dt.Rows.Add(dr);
                    Session["MyCart"] = dt;
                    btnShoppingCart.Text = dt.Rows.Count.ToString();



                }
            

        }

        protected void btnShoppingCart_Click(object sender, EventArgs e)
        {
            GetMyCart();
            lblCategoryName.Text = "product in cart";
            lblProducts.Text = "products details";
           // pnlMyCart.Visible = true;
            //pnlProducts.Visible = false;



        }

        protected void GetMyCart()
        {
            DataTable dtProducts;
            if (Session["MyCart"] != null)
            {
                dtProducts = (DataTable) Session["MyCart"];


            }
            else
            {
                dtProducts = new DataTable();
            }

            if (dtProducts.Rows.Count > 0)
            {

                txtTotalProduts.Text = dtProducts.Rows.Count.ToString();
                btnShoppingCart.Text = dtProducts.Rows.Count.ToString();

                dlCartProducts.DataSource = dtProducts ;
                dlCartProducts.DataBind();


               // dlCartProducts.DataSource = dtProducts;
              // dlCartProducts.DataBind();


                UpdateTototalBill();

                pnlMyCart.Visible = true;
                pnlCheckout.Visible = true;
                pnlEmptyCart.Visible = false;
                pnlCategory.Visible = false ;
                pnlProducts.Visible = false  ;
                pnlOrderPlacedSuccessfully.Visible = false;
                



            }
            else
            {
                pnlEmptyCart.Visible = true;
                pnlMyCart.Visible = false;
                pnlCheckout.Visible = false;
                pnlCategory.Visible = false;
                pnlCategory.Visible = false;
                pnlProducts.Visible = false;
                pnlOrderPlacedSuccessfully.Visible = false;
                dlCartProducts.DataSource = null;
                dlCartProducts.DataBind();
                txtTotalProduts.Text = "0";
                txtTotalPrice.Text = "0";
                btnShoppingCart.Text = "0";




            }







        }

        protected void btn_add_to_cart(object sender, EventArgs e)
        //baces for button
        {
            string productId = Convert.ToInt16((((Button) sender).CommandArgument)).ToString();
            String ProductQuantity = "1";
            DataListItem currentItem = (sender as Button).NamingContainer as DataListItem;

            Label lblAvailablestock = currentItem.FindControl("lblAvailableStock") as Label;

            if (Session["MyCart"] != null)
            //braces for if session
            {
                DataTable dt = (DataTable) Session["MyCart"];
                var checkProduct = dt.AsEnumerable().Where(r => r.Field<string>("ProductID") == productId);
                if (checkProduct.Count() == 0)
                {// brces for  check count
                    String query = "select * from Products where productID=" + productId + "";
                    DataTable dtproducts = GetData(query);

                    DataRow dr = dt.NewRow();
                    dr["productID"] = productId;
                    dr["Name"] = Convert.ToString(dtproducts.Rows[0]["Name"]);
                    dr["description"] = Convert.ToString(dtproducts.Rows[0]["description"]);
                    dr["price"] = Convert.ToString(dtproducts.Rows[0]["price"]);
                    dr["imageurl"] = Convert.ToString(dtproducts.Rows[0]["imageurl"]);
                    dr["ProductQuantity"] = ProductQuantity;
                  //  dr["AvailableSock"] = lblAvailablestock.Text;
                    dt.Rows.Add(dr);

                    Session["MyCart"] = dt;
                    btnShoppingCart.Text = dt.Rows.Count.ToString();
                 //   btnShoppingCart.Text = "Z";




                }// brces for  check count





            }//braces for if session
            else
            {
                String query = "select * from Products where ProductID=" + productId + "";
                DataTable dtProducts = GetData(query);
                DataTable dt = new DataTable();

                dt.Columns.Add("productID", typeof(string));
                dt.Columns.Add("Name", typeof(string));
                dt.Columns.Add("description", typeof(string));
                dt.Columns.Add("price", typeof(string));
                dt.Columns.Add("imageUrl", typeof(string));
                dt.Columns.Add("ProductQuantity", typeof(string));
                dt.Columns.Add("Availablestock", typeof(string));

                DataRow dr = dt.NewRow();
                dr["ProductID"] = productId;
                dr["Name"] = Convert.ToString(dtProducts.Rows[0]["Name"]);
                dr["description"] = Convert.ToString(dtProducts.Rows[0]["description"]);
                dr["Price"] = Convert.ToString(dtProducts.Rows[0]["price"]);
                dr["imageUrl"] = Convert.ToString(dtProducts.Rows[0]["imageUrl"]);
                dr["ProductQuantity"] = ProductQuantity;
                dr["AvailableStock"] = lblAvailablestock.Text;


                dt.Rows.Add(dr);
                Session ["MyCart"]=dt;

               btnShoppingCart.Text = dt.Rows.Count.ToString();

               // btnShoppingCart.Text = "aa ";







            }// braces for else 

           HighlightCartProduct();






        }//baces for button
    }

}